<?php 
/**
 * * Template Name: contact
 */
?>
<?php get_header() ?>

<div class="row">
    <div class="d-flex flex-column justify-content-center align-items-center">
        <?php  
            $image_id = get_field('ct_image');
            $image = wp_get_attachment_image($image_id);
            if ( get_field('ct_image') ) { 
                echo $image;
            }
        ?>
        <h5 class="p-3"><?php echo get_field('ct_phrase')?></h5>
        <p><?php echo get_field('ct_libelle')?></p>
        <p class="gras"><?php echo get_field('ct_telephone')?></p>
        <p><?php echo get_field('ct_commentaire')?></p>
        
        <div class="div-reseaux-sociaux">
            <a href="https://twitter.com/virtuanetx">
                <img src="http://virtuanetwork.test/wp-content/uploads/2021/11/twitter.png" alt="Twitter">
            </a> 
            <a href="https://www.linkedin.com/company/virtua-networks/">
                <img src="http://virtuanetwork.test/wp-content/uploads/2021/11/linkedin.png" alt="Linkedin">
            </a>
        </div>
        <div><?php the_content(); ?></div>
    </div>
</div>


<?php

// Vérifie que les données proviennent bien d'un formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    var_dump($_POST);
    // Vérifie que les données ne sont pas vides
    $name = $_POST["name"];
    $visitor_email = $_POST["email"];
    $message = $_POST["subject"];

    if (!filter_var($visitor_email, FILTER_VALIDATE_EMAIL)) {
          /* si l'email n'est pas saisie et valide ==> message d'erreur*/
        die("S'il vous plaît, veuillez entrer une adresse mail valide.");
    } 
    if (!isset($name)){
        die("S'il vous plaît, entrez votre nom.");
    }
    if (!isset($message)) {
        die("S'il vous plaît, entrez votre message.");
    } else {

        if(IsInjected($visitor_email))
        {
            echo "email non valide!";
            exit;
        }else{
            //composition de l'e-mail */
            $to = 'debraymartine.a@gmail.com';

            $email_subject = "Message envoyé depuis le Portfolio";

            $email_body = "Vous venez de recevoir un message de la part de $name.\n".
                                "Voici le message:\n $message";

            $headers .= "Reply-To: $visitor_email \r\n";

            //envoi du message */
            mail($to,$email_subject,$email_body,$headers);
        }
    }
}


function IsInjected($str)
{
    $injections = array('(\n+)',
           '(\r+)',
           '(\t+)',
           '(%0A+)',
           '(%0D+)',
           '(%08+)',
           '(%09+)'
           );
               
    $inject = join('|', $injections);
    $inject = "/$inject/i";
    
    if(preg_match($inject,$str))
    {
      return true;
    }
    else
    {
      return false;
    }
}
?>
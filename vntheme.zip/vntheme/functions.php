<?php


function vntheme_supports(){
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails', array( 'post', 'page', 'vntheme_slider', 'vntheme_banner') );
    add_theme_support('menus');
    register_nav_menu('header', 'En tête du menu');
}

function vntheme_register_assets(){
    /* on enregistre la feuille de style principal (style.css) dans le header*/
    wp_enqueue_style('vntheme_styles', get_stylesheet_uri());

    /* on enregistre la police dans le header*/
    wp_enqueue_style('vntheme_font', 'https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700&display=swap');

    wp_register_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css');
    wp_enqueue_style('bootstrap');
    wp_register_script('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js');
    wp_enqueue_script('bootstrap');
    
}

function vntheme_menu_link_class($attrs){
    $attrs['class'] = 'nav-link';
    return $attrs;
}

function vntheme_init(){
    register_taxonomy('solutions', 'post', [
        'labels' => [
            'name' => 'solutions'
        ],
        'show_in_rest' => true,
        'hierarchical' => true
        ]);
}

add_action('init', 'vntheme_init');
add_action('after_setup_theme', 'vntheme_supports');
add_action('wp_enqueue_scripts', 'vntheme_register_assets');
add_filter('nav_menu_link_attributes', 'vntheme_menu_link_class');


/*-----------------------------------------------------*/
/* création du custum post type pour le slider Clients */

function vntheme_slider_init() {

$labels = array(
    'name' => 'Logo Client Home',
    'singular_name' => 'Logo client',
    'add_new' => 'Ajouter un logo',
    'add_new_item' => 'Ajouter un logo client',
    'edit_new' => 'Modifier un logo client',
    'new_item' => 'Nouveau',
    'all_new' => 'Voir la liste',
    'view_item' => 'Voir l\'élément',
    'search_items' => 'Rechercher un logo client',
    'not_found' => 'Aucun élément trouvé',
    'not_found_in_trash' => 'Aucun élément dans la corbeille',
    'menu_name' => 'Logos Clients');

$args = array(
    'labels' => $labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true,
    'show_in_menu' => true,
    'query_var' => true,
    'rewrite' => true,
    'capability_type' => 'post',
    'has_archive' => false,
    'hierarchical' => false,
    'menu_position' => 10,
    'menu_icon' => get_stylesheet_directory_uri(), '/assets/image.png',
    'publicly_queryable' => false,
    'exclude_from_search' => true,
    'supports' => array('title', 'page-attributes', 'thumbnail', 'post-thumbnails')
);

register_post_type('vntheme_slider', $args);
}

add_action('init', 'vntheme_slider_init');

add_filter('manage_edit-vntheme_slider_columns', 'vntheme_col_change');

function vntheme_col_change($columns) {
    $columns['vntheme_slider_image_order'] = "Ordre";
    $columns['vntheme_slider_image'] = "Image affichée";

    return $columns;
}

add_action('manage_vntheme_slider_posts_custom_column', 'vntheme_content_show', 10, 2);

function vntheme_content_show($column, $post_id) {
    global $post;
    if ($column == 'vntheme_slider_image') {
        echo the_post_thumbnail(array(200, 100));
    }
    if ($column == 'vntheme_slider_image_order') {
        echo $post->menu_order;
    }
}

/*------------------------------------------------------------*/
/* création du custum post type pour la banbière Fournisseurs */

function vntheme_banner_init() {

    $labels = array(
        'name' => 'Logo Fournisseur Home',
        'singular_name' => 'Logo Fournisseur',
        'add_new' => 'Ajouter un logo',
        'add_new_item' => 'Ajouter un logo fournisseur',
        'edit_new' => 'Modifier un logo fournisseur',
        'new_item' => 'Nouveau',
        'all_new' => 'Voir la liste',
        'view_item' => 'Voir l\'élément',
        'search_items' => 'Rechercher un logo fournisseur',
        'not_found' => 'Aucun élément trouvé',
        'not_found_in_trash' => 'Aucun élément dans la corbeille',
        'menu_name' => 'Logos Fournisseurs');
    
    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'menu_position' => 10,
        'menu_icon' => get_stylesheet_directory_uri(), '/assets/image.png',
        'publicly_queryable' => false,
        'exclude_from_search' => true,
        'supports' => array('title', 'page-attributes', 'thumbnail', 'post-thumbnails')
    );
    
    register_post_type('vntheme_banner', $args);
    }
    
    add_action('init', 'vntheme_banner_init');
    
    add_filter('manage_edit-vntheme_banner_columns', 'vntheme_banner_col_change');
    
    function vntheme_banner_col_change($columns) {
        $columns['vntheme_banner_image_order'] = "Ordre";
        $columns['vntheme_banner_image'] = "Image affichée";
    
        return $columns;
    }
    
    add_action('manage_vntheme_banner_posts_custom_column', 'vntheme_banner_content_show', 10, 2);
    
    function vntheme_banner_content_show($column, $post_id) {
        global $post;
        if ($column == 'vntheme_banner_image') {
            echo the_post_thumbnail(array(200, 100));
        }
        if ($column == 'vntheme_banner_image_order') {
            echo $post->menu_order;
        }
    }

/* --------------------------- */
/* partie dashboard            */

function gpr_wp_dashboard_documentation() {
    $filedoc = __DIR__ ."\documentation.php";
    //var_dump($filedoc);
    //die();

    include($filedoc); //dans ce fichier importé figurera ce que l'on souhaite (images, texte, fonctionnalités, etc)
}

function gpr_wp_dashboard_setup() {

    wp_add_dashboard_widget( 'gpr_wp_dashboard_documentation', __( 'documentation' ),'gpr_wp_dashboard_documentation');
}

add_action('wp_dashboard_setup', 'gpr_wp_dashboard_setup');
        

?>


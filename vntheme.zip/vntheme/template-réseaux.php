<?php 
/**
 * * Template Name: réseaux
 */
?>
<?php get_header() ?>

<div class="headerpage">
    <div class="titre">
        <?php  
            $image_id = get_field('r_image');
            $image = wp_get_attachment_image($image_id);
            if ( get_field('r_image') ) { 
                echo $image;}
        ?>
        <h1><?php echo get_field('r_titre')?></h1>
    </div>
    <h5><?php echo get_field('r_phrase')?></h5>
    <p class="description"><?php echo get_field('r_description', false, false)?></p>
</div>

<?php
$args = array ('category_name' => 'Réseaux', 'posts_per_page' => 4, 'orderby' => 'date', 'order' => 'DESC' );
$category_posts = new WP_Query($args); ?>

<?php if ($category_posts->have_posts()) : ?>

    <?php $i=0; ?>
    <?php while ($category_posts->have_posts()) : $category_posts->the_post(); ?>
        <div class="row">
            <div class="col-sm-12 col-md-5 col-lg-5 p-3 <?php echo ($i & 1) ? 'order-first':'order-last';?>">
                <?php  
                $image_id = get_field('ar_image');
                $image = wp_get_attachment_image($image_id);
                if ( get_field('ar_image') ) { 
                    echo $image;}
                ?>
            </div>
            <div class="col-sm-12 col-md-5 col-lg-5 p-3 <?php echo ($i & 1) ? 'order-last':'order-first';?>">
                <h4><?php echo get_field('ar_titre'); ?></h4>
                <h5><?php echo get_field('ar_phrase'); ?></h5>
                <p><?php echo get_field('ar_description', false, false)?></p>
            </div>
        </div>
    <?php $i++; ?>
    <?php endwhile ?>

<?php else : ?>
    <h3>pas d'articles</h3>
<?php endif; ?>

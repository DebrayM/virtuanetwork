
<?php
$ressource = 'http://virtuanetwork.test/wp-content/uploads/2021/11/VirtuaNetworkDocumentation.pdf';
?>

<iframe src="<?php echo $ressource ?>"
     width="550" 
     height="650" 
     style="border:2px solid red">
</iframe>
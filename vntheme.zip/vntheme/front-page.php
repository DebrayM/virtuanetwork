
<?php get_header() ?>
<?php
$args = array ('category_name' => 'Home', 'posts_per_page' => 4, 'orderby' => 'date', 'order' => 'DESC' );
$category_posts = new WP_Query($args); ?>
<?php if ($category_posts->have_posts()) : ?>
<div class="row p-3 bg-color-grey div-margin">
    <div class="cadre-logo-home">
    <?php while ($category_posts->have_posts()) : $category_posts->the_post(); ?>
        <img src="http://virtuanetwork.test/wp-content/uploads/2021/11/LogoVirtuaNetworks.png" alt="Logo VirtuaNetwork" class="img-logo">
        <h1><?php echo get_field('i_titre')?></h1>
        <?php endwhile ?>
    </div>
</div>
<?php else : ?>
    <h3>pas d'articles</h3>
<?php endif; ?>

<main class="main-content">

<!-- section INFORMATION-->
    <!-- partie ordinateur -->
    <div class="row div-margin div_desk">
        <?php
        $args = array ('category_name' => 'Info-pc', 'posts_per_page' => 4, 'orderby' => 'date', 'order' => 'DESC' );
        $category_posts = new WP_Query($args); ?>
        <?php if ($category_posts->have_posts()) : ?>
        <div class="d-flex justify-content-center align-items-center">
            <?php while ($category_posts->have_posts()) : $category_posts->the_post(); ?>
            <div class="col-12 col-md-3 col-lg-3 p-3">
                <div class="info-img ">
                    <?php  
                        $image_id = get_field('ai_image-pc');
                        $image = wp_get_attachment_image($image_id);
                        if ( get_field('ai_image-pc') ) { 
                            echo $image;
                        }
                    ?>
                    <h3><?php echo get_field('ai_titre-pc'); ?></h3>
                    <p><?php echo get_field('ai_description-pc', false, false)?></p>
                </div>
            </div>
            <?php endwhile ?>
        </div>
    <?php else : ?>
    <h3>pas d'articles</h3>
    <?php endif; ?>
    </div>
    <!-- partie mobile -->
    <div class="row div-margin div_mobile">
        <?php
        $args = array ('category_name' => 'Info-mobile', 'posts_per_page' => 4, 'orderby' => 'date', 'order' => 'DESC' );
        $category_posts = new WP_Query($args); ?>
        <?php if ($category_posts->have_posts()) : ?>
        <div class="d-flex flex-column justify-content-center align-items-center">
            <?php while ($category_posts->have_posts()) : $category_posts->the_post(); ?>
            <h3><?php echo get_field('ai_titre'); ?></h3>
            <p><?php echo get_field('ai_description', false, false)?></p>
            <?php endwhile ?>
        </div>
        <?php else : ?>
        <h3>pas d'articles</h3>
        <?php endif; ?>
    </div>
<!-- section SOLUTIONS-->
<?php
$args = array ('category_name' => 'Cartes', 'posts_per_page' => 4, 'orderby' => 'date', 'order' => 'DESC' );
$category_posts = new WP_Query($args); ?>
<?php if ($category_posts->have_posts()) : ?>
    <div class="row text-center bg-color-grey div-margin">
        <h2>SOLUTIONS</h2>
        <div class="cadre">
        <?php while ($category_posts->have_posts()) : $category_posts->the_post(); ?>
        <a href="<?php echo get_field('act_permalien');?>">
        <div class="card-red">
            <h6><?php echo get_field('act_titre'); ?></h6>
            <?php  
                $image_id = get_field('act_image');
                $image = wp_get_attachment_image($image_id);
                if ( get_field('act_image') ) { 
                    echo $image;
                }
            ?>
        </div>
        </a>
        <?php endwhile ?>
        </div>
    </div>
    <?php else : ?>
    <h3>pas d'articles pour la section solutions</h3>
<?php endif; ?>
<!-- section SERVICES-->
<?php
$args = array ('category_name' => 'Info-services', 'posts_per_page' => 4, 'orderby' => 'date', 'order' => 'DESC' );
$category_posts = new WP_Query($args); ?>
<?php if ($category_posts->have_posts()) : ?>
    <div class="row d-flex justify-content-center align-items-center text-center div-margin">
    <h2>SERVICES</h2>
    <?php while ($category_posts->have_posts()) : $category_posts->the_post(); ?>
    <div class="col-12 col-md-4 col-lg-4 p-2">
        <div class="info-txt">
            <h3 class="txt-red gras"><?php echo get_field('ais_titre'); ?></h3>
            <p><?php echo get_field('ais_description', false, false)?></p>
        </div>
    </div>
    <?php endwhile ?>

    </div>
    <?php else : ?>
    <h3>pas d'articles pour la section SERVICES</h3>
<?php endif; ?>

<!-- section DATACENTER-->
<?php
$args = array ('category_name' => 'Info-Datacenter', 'posts_per_page' => 4, 'orderby' => 'date', 'order' => 'DESC' );
$category_posts = new WP_Query($args); ?>
<?php if ($category_posts->have_posts()) : ?>
    <div class="row text-center div-margin datacenter">
    <h2 class="h2-datacenter">DATACENTER</h2>
    <div class="div-datacenter">
    <?php while ($category_posts->have_posts()) : $category_posts->the_post(); ?>
        <div class="info-txt div-block">
            <h4><?php echo get_field('aid_titre'); ?></h4>
            <p><?php echo get_field('aid_description', false, false)?></p>
        </div>
    <?php endwhile ?>
    </div>
    </div>
    <?php else : ?>
    <h3>pas d'articles pour la section DATACENTER</h3>
<?php endif; ?>

<!-- section REFERENCES-->
<?php get_template_part('slider', 'home'); ?>
<!-- section PARTENARIAT-->
<?php get_template_part('banner', 'home'); ?>

</main>

<?php get_footer() ?>
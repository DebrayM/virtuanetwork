
</div> <!--fin container page-->
<div class="row div-margin-footer bg-color-grey">
    <!-- bouton contact et logo réseaux sociaux -->
    <div class="col-12 d-flex flex-column justify-content-center align-items-center">
    <a href="http://virtuanetwork.test/contact/" class="foot_btn_contact">Contact</a>
    <div class="div-reseaux-sociaux">
        <a href="https://twitter.com/virtuanetx">
            <img src="http://virtuanetwork.test/wp-content/uploads/2021/11/twitter.png" alt="Twitter">
        </a> 
        <a href="https://www.linkedin.com/company/virtua-networks/">
             <img src="http://virtuanetwork.test/wp-content/uploads/2021/11/linkedin.png" alt="Linkedin">
        </a>
    </div>
    </div>
</div>
<?php wp_footer() ?>
</body>
</html>
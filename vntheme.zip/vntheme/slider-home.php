
<?php
    $args = array(
        'post_type' => 'vntheme_slider',
        'post_per_page' => -1,
        'orderby' => 'menu_order',
        'order' => 'ASC'
    );
    $slider_query = new WP_Query($args);?>

<?php if ($slider_query->have_posts()): ?>

<section class="div_desk">
    <div class="titre_slider_banner">
    <h2>Nos références</h2>
    </div>
    <div class="container-scroll">
        <!-- ce container  permet de centrer le scoll dans la largeur de la page --> 
        <div class="scroller" id="id_scroll">

            <?php while($slider_query->have_posts()) : $slider_query->the_post(); ?>

            <!-- cette div reçoit le carousel des logos clients -->       
            <div class="client">
                <?php
                $thumbnail_html = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'Logos clients');
                $thumbnail_src = $thumbnail_html['0'];?>
                    <img src="<?php echo $thumbnail_src; ?>" alt="Logos Clients">
            </div>

            <?php endwhile ?>

        </div><!-- fin carousel des logos clients -->
    </div><!-- fin container-scroll -->
</section><!-- fin section-->

<?php else : ?>
    <h3>pas d'articles</h3>
<?php endif; ?>
